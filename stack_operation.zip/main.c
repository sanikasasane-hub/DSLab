/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>

int main()
{
    int Top=-1,Stack[10],x,n,i,choice;
    printf("\nEnter the size of stack");
    scanf("%d",&n);
    while(1)
    {
        printf("\n1.Push: insertion of element in stack \n2.Pop: deletion of element in stack \n3.Peek:show topmost element \n4.Underflow:check whether stack is empty \n5.Overflow:check whether stack is full \n6.Display:show the element in stack \n7.Exit");
        printf("\nEnter the choice");
        scanf("%d",&choice);
        
        switch(choice)
        {
            case 1:
            //Push: insertion of element
            if(Top==n-1)
            {
                printf("\nOverflow!!");
            }
            else
            {
                printf("\nEnter the element in stack");
                scanf("%d",&x);
                Top++;
                Stack[Top]=x;
                
            }
            break;
            
            case 2:
            //Pop:deletion of element
            if(Top==-1)
            {
                printf("\nUnderflow!!");
            }
            else
            {
                Top--;
            }
            break;
            
            case 3:
            //Display topmost element
            printf("Show the topmost element:%d\n",Stack[Top]);
            break;
            
            case 4:
            //Show Underflow or not
            if(Top==-1)
            {
                printf("\nUnderflow!!");
            }
            else
            {
                printf("\nNot Underflow!!");
            }
            break;
            
            case 5:
            //Show overflow or not
            if(Top==n-1)
            {
                printf("\nOverflow!!");
            }
            else
            {
                printf("\nNot Overflow!!");
            }
            break;
            
            case 6:
            //Display the Stack
            for(i=Top;i>=0;i--)
            {
                printf("\t\n%d",Stack[i]);
            }
            break;
            
            case 7:exit(0);
            default:printf("\nInvalid choice!!");
            break;
        }//end of switch
        
    }//end of while loop
    return 0;
}//end of main function 