/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int Q[10],i,n,x,R=-1,F=-1,choice;
    printf("Enter the size of queue");
    scanf("%d",&n);
    
    while(1)
    {
        printf("\n1.insertion of element in queue:enqueue \n2.deletion of element in queue:dequeue \n3.underflow:whether the stack is empty \n4.overflow:whether the stack is full \n5.peek:first element of stack \n6.display \n7.exit");
        printf("\n\nEnter the choice");
        scanf("%d",&choice);
        
        switch(choice)
        {
            case 1:
            //code for insertion of element
            printf("\nEnter the element for insertion in queue");
            scanf("%d",&x);
            if(R==n-1)
            {
                printf("\nOverflow");
            }
            else if (F==-1&&R==-1)
            {
                F=R=0;
                Q[R]=x;
            }
            else
            {
                R++;
                Q[R]=x;
            }
            break;
            
            case 2:
            //code for deletion of element
            
            if(F==-1&&R==-1)
            {
                printf("\nUnderflow");
            }
            else if(F==R)
            {
                printf("\nElement deleted from queue:%d",Q[F]);
                F=R=-1;
            }
            else
            {
                printf("\nElement deleted from queue:%d",Q[F]);
                F++;
            }
            break;
            
            case 3:
            //code for Underflow
            if(F==-1&&R==-1)
            {
                printf("Queue is empty:Underflow");
            }
            else
            {
                printf("Queue is not empty");
            }
            break;
            
            case 4:
            //code for Overflow
            if(R==n-1)
            {
                printf("Queue is full:Overflow");
            }
            else
            {
                printf("Queue is not full");
            }
            break;
            
            case 5:
            //code for peek element
            printf("The element at first position is %d",Q[F]);
            break;
            
            case 6:
            //code for display
            printf("\nDisplaying the element");
            for(int i=F;i<=R;i++)
            {
                printf("%d\t",Q[i]);
            }
            break;
            
            case 7:
            exit(0);
            break;
            
            default:
            printf("\nInvalid choice!!");
        }
    }

    return 0;
}