/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
int i,n,a,x,pos,Arr[10];
int main()
{
    int choice;

    printf("Enter the size of the array");
    scanf("%d",&n);
    //code for creation of an array
    printf("\nEnter the element for creation of array");
    for(i=0;i<n;i++)
    {
        scanf("%d",&Arr[i]);
    }
    while(1)
    {
        printf("\n1.insertion of element at first position \n2.insertion of element at any position \n3.insertion of element at last position \n4.deletion of element at first position \n5.deletion of element at any position \n6.deletion of element at last position \n7.display \n8.exit ");
        printf("\n\nEnter the choice");
        scanf("%d",&choice);
        
        switch(choice)
        {
            
            case 1:
            //code for insertion of element for first position
            printf("\nEnter the element");
            scanf("%d",&x);
            for(int i=n-1;i>=0;i--)
            {
                Arr[i+1]=Arr[i];
            }
            Arr[0]=x;
            n++;
            break;
            
            case 2:
            //code for insertion of element for any position
            printf("\nEnter the element");
            scanf("%d",&x);
            printf("\nEnter the position for insertion");
            scanf("%d",&pos);
            for (int i=n-1;i>=pos-1;i--)
            {
                Arr[i+1]=Arr[i];
            }
            Arr[pos-1]=x;
            n++;
            break;
            
            case 3:
            //code for insertion of element for last position
            printf("\nEnter the element");
            scanf("%d", &x);
            Arr[n]=x;
            n++;
            break;
            
            case 4:
            //code for deletion of element for first position
            printf("\nDelete the element");
            for(int i=0;i<=n-1;i++)
            {
                Arr[i]=Arr[i+1]; //shifting the array
            }
            n--;
            break;
            
            case 5:
            //code for deletion of element for any position
            printf("\nDelete the element");
            for(int i=pos-1;i<=n-1;i++)
            {
                Arr[i]=Arr[i+1]; //shifting an array
            }
            n--;
            break;
            
            case 6:
            //code for deletion of element for last position
            printf("\nDelete the element");
            n--;
            break;
            
            case 7:
            //code for display
            printf("\nDisplaying the elements");
            for(int i=0;i<n;i++)
            {
                printf("%d\t",Arr[i]); //writing an array
            }
            break;
            
            case 8:exit(0);
            default:printf("\nInvalid choice!!");
            
            
        }//end of switch
    
    }//end of while loop

    return 0;
}//end of main function
